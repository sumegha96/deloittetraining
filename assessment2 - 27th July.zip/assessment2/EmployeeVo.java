package assessment2;

public class EmployeeVo {
	private int empId;
	private String empName;
	private double annualIncome, incomeTax;
	
	//returns EmpId
	public int getEmpId() {
		return empId;
	}
	//sets EmpId
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	//returns EmpName
	public String getEmpName() {
		return empName;
	}
	//sets EmpName
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	//returns AnnualIncome
	public double getAnnualIncome() {
		return annualIncome;
	}
	//sets AnnualIncome
	public void setAnnualIncome(double annualIncome) {
		this.annualIncome = annualIncome;
	}
	//returns IncomeTax
	public double getIncomeTax() {
		return incomeTax;
	}
	//sets IncomeTax
	public void setIncomeTax(double incomeTax) {
		this.incomeTax = incomeTax;
	}

	@Override
	public String toString() {
		return "EmployeeVo [empId=" + empId + ", empName=" + empName + ", annualIncome=" + annualIncome + ", incomeTax="
				+ incomeTax + "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(annualIncome);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + empId;
		result = prime * result + ((empName == null) ? 0 : empName.hashCode());
		temp = Double.doubleToLongBits(incomeTax);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeVo other = (EmployeeVo) obj;
		if (Double.doubleToLongBits(annualIncome) != Double.doubleToLongBits(other.annualIncome))
			return false;
		if (empId != other.empId)
			return false;
		if (empName == null) {
			if (other.empName != null)
				return false;
		} else if (!empName.equals(other.empName))
			return false;
		if (Double.doubleToLongBits(incomeTax) != Double.doubleToLongBits(other.incomeTax))
			return false;
		return true;
	}
	
	public EmployeeVo(int empId, String empName, double annualIncome, double incomeTax) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.annualIncome = annualIncome;
		this.incomeTax = incomeTax;
	}
	
	
}
