package assessment2;

public class EmployeeBo {

	public static void calincomeTax(EmployeeVo employeeVo)
	{
				double annualIncome=employeeVo.getAnnualIncome();
				double incomeTax = 0;
				//5 percent income tax
				if(annualIncome>0 && annualIncome<5000)
					incomeTax=annualIncome*0.05;
				//10 percent income tax
				else if(annualIncome>=5000 && annualIncome<10000)
					incomeTax=annualIncome*0.1;
				//15 percent income tax
				else if(annualIncome>=10000)
					incomeTax=annualIncome*0.15;
				employeeVo.setIncomeTax(incomeTax);
				System.out.println(employeeVo.getIncomeTax());
	
	
	}
}
