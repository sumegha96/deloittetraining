package assessment2;

import java.util.Scanner;

public class Main {
		public static void main(String[] args) {
			String status;
			int i;
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter no of numbers you wish to enter: ");
			int noOfNumbers=scanner.nextInt();
			int[] arr = new int[noOfNumbers];
			System.out.println("Enter numbers: ");
			for( i=0; i<noOfNumbers ; i++)
			{
				arr[i]=scanner.nextInt();
			}
			if(UserMainCode.checkTripplets(arr))
				status="TRUE";
			else
				status="FALSE";
			System.out.println(status);
		}
}
