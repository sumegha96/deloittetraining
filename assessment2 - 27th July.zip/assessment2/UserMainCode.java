package assessment2;

import java.util.Scanner;

class UserMainCode {
	 	static boolean checkTripplets(int[] arr)
	 	{
	 	   int i;
	       for(i=0; i<arr.length; i++)
	       {
	       		if(i==((arr.length)-2))
	       			break;
	       		if(arr[i]==arr[i+1]) 
	       			if(arr[i]==arr[i+2])
	       			return true;
	       	 }
	 	return false;
	 	}
}	
	 

