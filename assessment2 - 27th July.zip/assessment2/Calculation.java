package assessment2;

import java.util.Scanner;

public class Calculation {

	public static void main(String[] args) {
		
		Arithmetic ref1 = new Addition();
		Arithmetic ref2 = new Subtraction();
		Arithmetic ref3 = new Multiplication();
		Arithmetic ref4 = new Division();
		//array of references
		Arithmetic[] ref = {ref1, ref2, ref3, ref4};
		int choice;	
		
		System.out.println("1. Addition \n2.Subtraction \n3.Multiplication \n4.Division");
		System.out.println("Enter your choice: ");
		Scanner scanner = new Scanner(System.in);
		//accepting user choice
		choice = scanner.nextInt();
		System.out.println("Enter two numers: ");
		//accepting two user input numbers
		int num1=scanner.nextInt();
		int num2=scanner.nextInt();
		//output after the calculation
		System.out.println("Result is: " + ref[choice-1].calculate(num1, num2));
	}

}
