package assessment2;

import java.util.Scanner;

abstract class Arithmetic {
private int num1, num2;
public int result;
public abstract int calculate(int num1, int num2);

//returns num1
public int getNum1() {
	return num1;
}

//sets num1
public void setNum1(int num1) {
	this.num1 = num1;
}

//returns num2
public int getNum2() {
	return num2;
}

//sets num2
public void setNum2(int num2) {
	this.num2 = num2;
}
}

class Addition extends Arithmetic{
	@Override
	public int calculate(int num1, int num2) {
		result=num1+num2;
		return result;
	}
}

class Subtraction extends Arithmetic{
	@Override
	public int calculate(int num1, int num2) {
		result=num1-num2;
		return result;
	}	
}

class Multiplication extends Arithmetic{
	@Override
	public int calculate(int num1, int num2) {
		result=num1*num2;
		return result;
	}
}

class Division extends Arithmetic{
	@Override
	public int calculate(int num1, int num2) {
		result=num1/num2;
		return result;
	}
}
